import scrapy

class QiushiSpider(scrapy.Spider):
    name ="qiushi"
    allowed_domains = ['https://www.qiushibaike.com']

    def start_requests(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36',
        }
        urls = [
            'https://www.qiushibaike.com/text/page/1/',
            'https://www.qiushibaike.com/text/page/2/',
        ]
        for url in urls:
            yield scrapy.Request(url=url,callback=self.parse,headers=headers)

    def parse(self, response):
        #第一版程序，保存网页用的
        # page = response.url.split("/")[-2]
        # filename = 'qiushi-%s.html' % page
        # with open(filename, 'wb') as f:
        #     f.write(response.body)
        # self.log('Saved file %s' % filename)
        test = response.xpath('//*[@class="col1 old-style-col1"]')
        testtt = test.xpath('./div')

        for content_div in testtt:
            yield {
                'author' : content_div.xpath('./div/a[2]/h2/text()').get(),
                'content': content_div.xpath('./a/div/span/text()').getall(),
            }
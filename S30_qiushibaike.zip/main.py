from scrapy.cmdline import execute
#普通的运行
execute(["scrapy","crawl","qiushi"])
#保存一个json
#execute(["scrapy","crawl","qiushi","-o","qiushi.json"])
import scrapy

class QiushiSpider(scrapy.Spider):
    name ="qiushibaike"
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36'
    }
    def start_request(self):
        urls = [
            # 'https://www.qiushibaike.com/text/page/1/',
            # 'https://www.qiushibaike.com/text/page/2/',
            'https://www.qiushibaike.com/'
        ]
        for url in urls:
            yield scrapy.Request(url=url,callback=self.parse,headers=self.headers)

    def parse(self, response):
        page = response.url.split("/")[-2]
        filename = 'qiushi-%s.html' % page
        with open(filename, 'wb') as f:
            f.write(response.body)
        self.log('Saved file %s' % filename)